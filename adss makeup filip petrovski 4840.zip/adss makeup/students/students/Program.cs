﻿using System;

namespace Students
{
    class Program
    {
        static int Max(int[] arr, int n)
        {
            int max = arr[0];
            for (int i = 0; i < n; i++)
            {
                if (max < arr[i])
                    max = arr[i];
            }
            return max;
        }
        static int Min(int[] arr, int n)
        {
            int min = arr[0];
            for (int i = 0; i < n; i++)
            {
                if (min > arr[i])
                    min = arr[i];
            }
            return min;
        }
        static int CountOccurances(int[] arr, int n, int value)
        {
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                if (value == arr[i])
                    count++;
            }
            return count;
        }
        static void Main(string[] args)
        {
            int n;
            int[] arr = new int[8];
            Console.WriteLine("Insert number of students");
            n = int.Parse(Console.ReadLine());
            try
            {
                if (n > 8 || n <= 0)
                    throw new Exception("Number must be <= 8");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Insert new number");
                n = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Input the age for each student");
            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());

            }
            int max = Max(arr, n);
            int maxOccurances = CountOccurances(arr, n, max);
            int min = Min(arr, n);
            int minOccurances = CountOccurances(arr, n, min);
            Console.WriteLine("Youngest student in the group is " + min + " years old.");
            if (minOccurances > 1)
            {
                Console.WriteLine("There " + minOccurances + " are students at that age in the group");
            }
            Console.WriteLine("Oldest student in the group is " + max + " years old.");
            if (maxOccurances > 1)
            {
                Console.WriteLine("There " + maxOccurances + " are students at that age in the group");
            }
        }
    }
}